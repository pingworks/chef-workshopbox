(function() {
  var basename;

  basename = require('path').basename;

  module.exports = {
    activate: function(state) {
      return atom.workspace.observeTextEditors((function(_this) {
        return function(editor) {
          var rspecGrammar;
          if (!_this._isRspecFile(editor.getPath())) {
            return;
          }
          rspecGrammar = atom.grammars.grammarForScopeName('source.ruby.rspec');
          if (rspecGrammar == null) {
            return;
          }
          return editor.setGrammar(rspecGrammar);
        };
      })(this));
    },
    deactivate: function() {},
    serialize: function() {},
    _isRspecFile: function(filename) {
      var rspec_filetype;
      rspec_filetype = 'spec.rb';
      return basename(filename).slice(-rspec_filetype.length) === rspec_filetype;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvdGVzdHVzZXIvLmF0b20vcGFja2FnZXMvbGFuZ3VhZ2UtcnNwZWMvbGliL2xhbmd1YWdlLXJzcGVjLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxRQUFBOztBQUFBLEVBQUMsV0FBWSxPQUFBLENBQVEsTUFBUixFQUFaLFFBQUQsQ0FBQTs7QUFBQSxFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQ0U7QUFBQSxJQUFBLFFBQUEsRUFBVSxTQUFDLEtBQUQsR0FBQTthQUNSLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWYsQ0FBa0MsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsTUFBRCxHQUFBO0FBQ2hDLGNBQUEsWUFBQTtBQUFBLFVBQUEsSUFBQSxDQUFBLEtBQWUsQ0FBQSxZQUFELENBQWMsTUFBTSxDQUFDLE9BQVAsQ0FBQSxDQUFkLENBQWQ7QUFBQSxrQkFBQSxDQUFBO1dBQUE7QUFBQSxVQUNBLFlBQUEsR0FBZSxJQUFJLENBQUMsUUFBUSxDQUFDLG1CQUFkLENBQWtDLG1CQUFsQyxDQURmLENBQUE7QUFFQSxVQUFBLElBQWMsb0JBQWQ7QUFBQSxrQkFBQSxDQUFBO1dBRkE7aUJBR0EsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsWUFBbEIsRUFKZ0M7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQyxFQURRO0lBQUEsQ0FBVjtBQUFBLElBT0EsVUFBQSxFQUFZLFNBQUEsR0FBQSxDQVBaO0FBQUEsSUFTQSxTQUFBLEVBQVcsU0FBQSxHQUFBLENBVFg7QUFBQSxJQVdBLFlBQUEsRUFBYyxTQUFDLFFBQUQsR0FBQTtBQUNaLFVBQUEsY0FBQTtBQUFBLE1BQUEsY0FBQSxHQUFpQixTQUFqQixDQUFBO2FBQ0EsUUFBQSxDQUFTLFFBQVQsQ0FBa0IsQ0FBQyxLQUFuQixDQUF5QixDQUFBLGNBQWUsQ0FBQyxNQUF6QyxDQUFBLEtBQW9ELGVBRnhDO0lBQUEsQ0FYZDtHQUhGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/testuser/.atom/packages/language-rspec/lib/language-rspec.coffee
